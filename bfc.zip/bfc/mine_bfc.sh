#!/bin/bash
./vkminer -a bitfree -o stratum+tcp://ss.bfcpool.com:3333 -u aicoin.1 -t 1
